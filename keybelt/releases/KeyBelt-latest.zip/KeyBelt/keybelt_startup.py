# -*- coding: utf-8 -*-
"""
KeyBelt - userSetup.py startup block
====================================

Pure-Python helpers (no Maya import at module level) shared by drag_n_drop.py
(installer) and keybelt_core.py (Settings > General > "Load at Maya startup").
They add / remove the managed auto-start block of KeyBelt in the *versioned*
userSetup.py (<maya prefs>/<version>/scripts/userSetup.py), between the markers

    # >>> KeyBelt >>>
    # <<< KeyBelt <<<

Everything else in userSetup.py is left untouched. Before each write the file
is copied to userSetup.py.bak; the new content is written to a temp file and
swapped in with os.replace(). Newline style and utf-8 (BOM) are preserved.
"""

import os
import re
import shutil
import sys

MARKER_BEGIN = "# >>> KeyBelt >>>"
MARKER_END = "# <<< KeyBelt <<<"

# Text that identifies "KeyBelt is loaded by that file" in other files.
OTHER_FILE_TOKEN = "keybelt_core"

_BLOCK_RE = re.compile(
    r"^[ \t]*" + re.escape(MARKER_BEGIN) + r".*?" + re.escape(MARKER_END) + r"[^\n]*(?:\n|$)",
    re.DOTALL | re.MULTILINE,
)


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
def root_dir():
    """Folder that contains keybelt_core.py (the package root)."""
    return os.path.dirname(os.path.abspath(__file__))


def user_setup_path():
    """Versioned userSetup.py (<prefs>/<version>/scripts/userSetup.py)."""
    import maya.cmds as cmds
    path = cmds.internalVar(userScriptDir=True)
    if not os.path.isdir(path):
        os.makedirs(path)
    return os.path.join(path, "userSetup.py")


def other_user_setup_path(versioned=None):
    """Non-versioned <maya prefs>/scripts/userSetup.py (hand-written, never edited here)."""
    versioned = versioned or user_setup_path()
    scripts_dir = os.path.dirname(os.path.abspath(versioned))
    prefs_root = os.path.dirname(os.path.dirname(scripts_dir))
    return os.path.join(prefs_root, "scripts", "userSetup.py")


# ---------------------------------------------------------------------------
# Package registration + bootstrap code (shelf button, userSetup.py, generated commands)
# ---------------------------------------------------------------------------
# KeyBelt is imported as the package ``keybelt`` (registered explicitly from the
# folder, whatever it is called). Its root folder is NEVER put on sys.path, so its
# generic module names (main, styles, RadialMenu ...) cannot collide with any other
# toolset loaded in the same Maya session.
#
# REGISTER_CODE is the ONE snippet every entry point uses. It needs nothing but the
# standard library, so it also works in a fresh scope where nothing is imported.
REGISTER_CODE = '''import os as _kb_os, sys as _kb_sys, importlib.util as _kb_ilu
_kb_root = {root!r}
_kb_cur = _kb_sys.modules.get("keybelt")
_kb_paths = list(getattr(_kb_cur, "__path__", None) or [])
if not (_kb_paths and _kb_os.path.normcase(_kb_os.path.abspath(_kb_paths[0])) == _kb_os.path.normcase(_kb_os.path.abspath(_kb_root))):
    for _kb_n in [_n for _n in list(_kb_sys.modules) if _n == "keybelt" or _n.startswith("keybelt.")]:
        _kb_sys.modules.pop(_kb_n, None)
    _kb_spec = _kb_ilu.spec_from_file_location("keybelt", _kb_os.path.join(_kb_root, "__init__.py"), submodule_search_locations=[_kb_root])
    _kb_pkg = _kb_ilu.module_from_spec(_kb_spec)
    _kb_sys.modules["keybelt"] = _kb_pkg
    _kb_spec.loader.exec_module(_kb_pkg)
'''


def register_code(root, oneline=False):
    """Python source that registers the ``keybelt`` package for ``root``.

    oneline=True returns a single physical line (``exec('...')``) for places that
    need ``stmt; stmt`` style commands (workspaceControl uiScript ...).
    """
    code = REGISTER_CODE.format(root=os.path.abspath(root))
    return "exec({0!r})".format(code) if oneline else code


def ensure_package(root=None):
    """Register the ``keybelt`` package in this interpreter (idempotent). Returns it."""
    exec(register_code(root or root_dir()), {})
    return sys.modules["keybelt"]


# Applies a staged update (<parent>/KeyBelt_pending) BEFORE the package is imported.
# Skipped when keybelt is already loaded in this session (its .pyd files are locked).
# keybelt_update.apply_pending() does nothing for a development source folder.
APPLY_CODE = '''try:
    import os as _kb_a_os, sys as _kb_a_sys, importlib.util as _kb_a_ilu
    if "keybelt.keybelt_core" not in _kb_a_sys.modules:
        _kb_a_s = _kb_a_ilu.spec_from_file_location("_keybelt_update_boot", _kb_a_os.path.join(@ROOT@, "keybelt_update.py"))
        _kb_a_m = _kb_a_ilu.module_from_spec(_kb_a_s)
        _kb_a_s.loader.exec_module(_kb_a_m)
        _kb_a_m.apply_pending(@ROOT@)
except Exception as _kb_a_e:
    print("KeyBelt: pending update not applied: " + str(_kb_a_e))
'''


def apply_code(root, oneline=False):
    """Source that applies a staged update for ``root`` (stdlib only)."""
    code = APPLY_CODE.replace("@ROOT@", repr(os.path.abspath(root)))
    return "exec({0!r})".format(code) if oneline else code


def apply_pending_update(root=None):
    """Apply a staged update now (same as the generated bootstrap). True when swapped."""
    import importlib.util
    root = root or root_dir()
    if "keybelt.keybelt_core" in sys.modules:
        return False
    spec = importlib.util.spec_from_file_location(
        "_keybelt_update_boot", os.path.join(root, "keybelt_update.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.apply_pending(root)


def command_code(root, body, oneline=False):
    """Source that applies a pending update, registers the package, imports keybelt_core
    as ``_kb_core`` and runs body.

    ``body`` may refer to ``_kb_core`` (e.g. ``_kb_core.show()``).
    """
    imp = "import keybelt.keybelt_core as _kb_core"
    if oneline:
        return "{0}; {1}; {2}; {3}".format(apply_code(root, True), register_code(root, True), imp, body)
    return "{0}{1}{2}\n{3}\n".format(apply_code(root), register_code(root), imp, body)


def bootstrap(root, call):
    """Shelf-button / userSetup code that (re)loads KeyBelt: ``keybelt_core.<call>``."""
    return command_code(root, "_kb_core.{0}".format(call))


def block_text(root=None):
    """Managed block (LF newlines, ends with a newline)."""
    root = root or root_dir()
    # Release builds: show_startup() then a deferred, background, notify-only update check.
    body = command_code(
        root,
        "_kb_core.show_startup()\n"
        "import keybelt.keybelt_update as _kb_up\n"
        "_kb_up.startup_check()")
    indented = "".join(
        ("        " + line if line.strip() else line) for line in body.splitlines(True)
    )
    return (
        MARKER_BEGIN + "\n"
        "# Managed by KeyBelt (Settings > General > Startup, or drag_n_drop.py). Re-drop the\n"
        "# installer to update, or untick \"Load at Maya startup\" to remove this block.\n"
        "def _keybelt_startup():\n"
        "    try:\n"
        + indented +
        "    except Exception as _kb_err:\n"
        "        print(\"KeyBelt: startup failed: {0}\".format(_kb_err))\n"
        "\n"
        "try:\n"
        "    import maya.cmds as _kb_cmds\n"
        "    import maya.utils as _kb_utils\n"
        "    if not _kb_cmds.about(batch=True):\n"
        "        _kb_utils.executeDeferred(_keybelt_startup)\n"
        "except Exception as _kb_err:\n"
        "    print(\"KeyBelt: could not schedule startup: {0}\".format(_kb_err))\n"
        + MARKER_END + "\n"
    )


# ---------------------------------------------------------------------------
# File IO
# ---------------------------------------------------------------------------
def _read(path):
    """Return (text with LF newlines, newline style, has_bom)."""
    if not path or not os.path.isfile(path):
        return "", "\n", False
    with open(path, "rb") as fh:
        raw = fh.read()
    bom = raw.startswith(b"\xef\xbb\xbf")
    if bom:
        raw = raw[3:]
    text = raw.decode("utf-8", "replace")
    crlf = text.count("\r\n")
    newline = "\r\n" if crlf and crlf >= text.count("\n") - crlf else "\n"
    return text.replace("\r\n", "\n"), newline, bom


def _write(path, text, newline, bom):
    """Backup + atomic write."""
    if os.path.isfile(path):
        shutil.copyfile(path, path + ".bak")
    data = text.replace("\n", newline).encode("utf-8")
    if bom:
        data = b"\xef\xbb\xbf" + data
    tmp = path + ".tmp"
    with open(tmp, "wb") as fh:
        fh.write(data)
    os.replace(tmp, path)


def _splice(text, match, replacement):
    """Replace match with replacement (or cut it), keeping one blank line around it."""
    before = text[:match.start()].rstrip("\n")
    after = text[match.end():].lstrip("\n")
    parts = [p for p in (before, replacement.strip("\n") if replacement else "", after) if p]
    out = ("\n\n".join(parts)) if parts else ""
    if out and not out.endswith("\n"):
        out += "\n"
    return out


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def is_enabled(path=None):
    """True when the KeyBelt block is in userSetup.py."""
    return bool(_BLOCK_RE.search(_read(path or user_setup_path())[0]))


def set_enabled(enabled, root=None, path=None):
    """Add / refresh (enabled) or remove (disabled) the block.

    Returns True when the file was written.
    """
    path = path or user_setup_path()
    text, newline, bom = _read(path)
    new = text
    match = _BLOCK_RE.search(new)
    if enabled:
        block = block_text(root)
        if match:
            new = _splice(new, match, block)
        else:
            new = (new.rstrip("\n") + "\n\n" + block) if new.strip() else block
    else:
        while match:
            new = _splice(new, match, "")
            match = _BLOCK_RE.search(new)
        if not new.strip():
            new = ""

    if os.path.isfile(path):
        if new == text:
            return False
    elif not new:
        return False
    _write(path, new, newline, bom)
    return True


def other_file_mentioning_keybelt(versioned=None):
    """Path of the non-versioned userSetup.py if it mentions KeyBelt, else None."""
    try:
        other = other_user_setup_path(versioned)
        if os.path.isfile(other) and OTHER_FILE_TOKEN in _read(other)[0]:
            return other
    except Exception:
        pass
    return None
