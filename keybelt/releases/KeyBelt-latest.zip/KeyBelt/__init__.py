"""
KeyBelt - Animation toolset for Maya

A collection of Maya animation tools.
"""

__version__ = "0.2.0"
__author__ = "Andreu"
__description__ = "Animation toolset for Maya"

# Toolbox information dictionary (matches the pattern used by individual tools)
TOOLBOX_INFO = {
    "name": "KeyBelt",
    "version": __version__,
    "author": __author__,
    "description": __description__
}


# --- release build helpers (injected by KeyBelt_dev/build.py) -------------------------------
def _kb_find(path):
    """path of <stem>.py, or of the compiled <stem>.<abi>.pyd that replaces it (else None)."""
    import os as _os
    import importlib.machinery as _m
    if _os.path.isfile(path):
        return path
    stem = _os.path.splitext(path)[0]
    for suffix in _m.EXTENSION_SUFFIXES:
        if _os.path.isfile(stem + suffix):
            return stem + suffix
    return None


def _kb_exists(path):
    return _kb_find(path) is not None


def _kb_spec(name, path):
    """importlib spec for a sibling module given by its .py path (the .pyd in release builds)."""
    import os as _os
    import importlib.util as _u
    found = _kb_find(path)
    if found is None or found == path:
        return _u.spec_from_file_location(name, path)
    rel = _os.path.relpath(_os.path.splitext(path)[0], list(__path__)[0])
    return _u.spec_from_file_location("keybelt." + rel.replace(_os.sep, "."), found)


def _kb_slot(cb):
    """Release builds: make a Cython-compiled callback usable as a Qt slot.

    PySide2 cannot trim the signal arguments of / register a dynamic slot for a Cython function
    or bound method (RecursionError, or "takes no arguments (1 given)"). Compiled modules are
    rewritten at build time to connect through this plain-Python adapter, which drops the
    surplus signal arguments (like PySide does for Python slots) and keeps only a weak
    reference to the receiver. Anything that is not a Cython function is returned unchanged.
    """
    import weakref
    func = getattr(cb, "__func__", cb)
    if type(func).__name__ != "cython_function_or_method":
        return cb
    code = getattr(func, "__code__", None)
    if code is None:
        return cb
    owner = getattr(cb, "__self__", None)
    nargs = max(code.co_argcount - (1 if owner is not None else 0), 0)
    varargs = bool(code.co_flags & 0x04)
    if owner is None:
        def slot(*args):
            return cb(*(args if varargs else args[:nargs]))
        return slot
    cache = globals().setdefault("_KB_SLOT_CACHE", weakref.WeakKeyDictionary())
    try:
        per_owner = cache.setdefault(owner, {})
    except TypeError:
        per_owner = None
    if per_owner is not None and func in per_owner:
        return per_owner[func]          # same adapter again: disconnect(self.method) keeps working
    try:
        ref = weakref.WeakMethod(cb)
    except TypeError:
        ref = lambda: cb

    def slot(*args):
        method = ref()
        if method is not None:
            return method(*(args if varargs else args[:nargs]))
    if per_owner is not None:
        per_owner[func] = slot
    return slot
