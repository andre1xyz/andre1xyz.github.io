# -*- coding: utf-8 -*-
"""
KeyBelt installer
=================

Drag this file into a Maya viewport to install KeyBelt:

* creates (or reuses) a shelf tab called "KeyBelt" with a single KeyBelt button
* adds an auto-start block to your userSetup.py (between the
  "# >>> KeyBelt >>>" / "# <<< KeyBelt <<<" markers). The same block can be
  toggled later in Settings > General > Startup ("Load at Maya startup")

Release builds (a BUILD_INFO.json next to this file) are first copied to a stable
per-user folder, <maya user app dir>/KeyBelt (e.g. Documents/maya/KeyBelt, the same for
every Maya version); the shelf button and the userSetup block point there, so the
unzipped download can be deleted afterwards. An older install is overwritten; when
KeyBelt is currently loaded (files locked) the new version is staged as KeyBelt_pending
and applied the next time Maya starts. A development source folder (no BUILD_INFO.json)
is installed in place, exactly as before.

Re-dropping the file is safe: the shelf button is replaced and the userSetup
block is updated (e.g. after you moved the KeyBelt folder).

To remove everything again run, in the Maya Script Editor (Python tab):

    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "keybelt_installer", r"<path to the KeyBelt folder>/drag_n_drop.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.uninstall()

(KeyBelt never puts its folder on sys.path: it is loaded as the package
"keybelt", so it cannot clash with other toolsets that use the same module names.)

Nothing is installed when this module is merely imported. Installation only
happens from Maya's drop callback (onMayaDroppedPythonFile) or when the file
is executed as __main__.
"""

import os
import re
import shutil
import sys
import time

import maya.cmds as cmds
import maya.mel as mel

SHELF_NAME = "KeyBelt"
BUTTON_LABEL = "KeyBelt"
BUTTON_ANNOTATION = "KeyBelt"
BUTTON_DOCTAG = "KeyBelt"

_STAMP_OPTIONVAR = "keybeltInstallStamp"

try:
    _STRING_TYPES = (basestring,)  # noqa: F821  (Python 2)
except NameError:
    _STRING_TYPES = (str,)


def _startup_module(root=None):
    """Load keybelt_startup (the shared userSetup.py / bootstrap helpers) by file path.

    The installer may be dropped into Maya from anywhere. The KeyBelt folder is NOT
    added to sys.path and the module is loaded under a private name, so nothing
    else in the Maya session is affected.
    """
    import importlib.util
    root = _root_dir(root)
    spec = importlib.util.spec_from_file_location(
        "_keybelt_startup_installer", os.path.join(root, "keybelt_startup.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
def _root_dir(hint=None):
    """Folder that contains keybelt_core.py (the KeyBelt root)."""
    if hint and isinstance(hint, _STRING_TYPES):
        cand = hint if os.path.isdir(hint) else os.path.dirname(hint)
        if os.path.isfile(os.path.join(cand, "keybelt_core.py")) or _is_release(cand):
            return os.path.abspath(cand)
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except NameError:
        raise RuntimeError("KeyBelt: cannot locate the installer folder (no __file__).")


def _is_release(root):
    """True for a protected release build (BUILD_INFO.json present), False for dev source."""
    return os.path.isfile(os.path.join(root, "BUILD_INFO.json"))


def _stable_install_dir():
    """<maya user app dir>/KeyBelt, independent of the Maya version."""
    return os.path.join(os.path.abspath(cmds.internalVar(userAppDir=True)), "KeyBelt")


def _same_path(a, b):
    return os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(b))


def _load_updater(root):
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "_keybelt_update_installer", os.path.join(root, "keybelt_update.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _copy_tree(src, dst):
    shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))


def _deploy_release(root, target):
    """Copy the release folder ``root`` to ``target``. Returns "installed" or "pending".

    "pending" = the existing install is locked (KeyBelt is loaded): the new version is
    staged as <parent>/KeyBelt_pending and swapped in by the next Maya start.
    """
    parent = os.path.dirname(target)
    if not os.path.isdir(parent):
        os.makedirs(parent)
    if not os.path.exists(target):
        _copy_tree(root, target)
        return "installed"
    old = os.path.join(parent, "KeyBelt_old")
    shutil.rmtree(old, ignore_errors=True)
    try:
        os.rename(target, old)
    except OSError:
        _load_updater(root).stage_folder(root, root=target)
        return "pending"
    try:
        _copy_tree(root, target)
    except Exception:
        shutil.rmtree(target, ignore_errors=True)
        os.rename(old, target)
        raise
    shutil.rmtree(old, ignore_errors=True)
    return "installed"


def _icon_path(root):
    path = os.path.join(root, "branding", "icons", "keybelt_shelf.png")
    return path if os.path.isfile(path) else "commandButton.png"


def _user_script_dir():
    path = cmds.internalVar(userScriptDir=True)
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


def _user_setup_path():
    return os.path.join(_user_script_dir(), "userSetup.py")


# ---------------------------------------------------------------------------
# Bootstrap code (used by the shelf button; userSetup.py block: keybelt_startup).
# It registers the package "keybelt" from the absolute KeyBelt folder, then runs it.
# ---------------------------------------------------------------------------
def _bootstrap(root, call):
    return _startup_module(root).bootstrap(root, call)


# ---------------------------------------------------------------------------
# Shelf
# ---------------------------------------------------------------------------
def _shelf_top_level():
    try:
        top = mel.eval("$tmp = $gShelfTopLevel")
        if top:
            return top
    except Exception:
        pass
    return "ShelfLayout"


def _save_shelves():
    try:
        mel.eval("saveAllShelves $gShelfTopLevel;")
        return True
    except Exception:
        pass
    try:
        cmds.saveAllShelves(cmds.internalVar(userShelfDir=True))
        return True
    except Exception as err:
        print("KeyBelt: could not save shelves ({0})".format(err))
    return False


def _remove_keybelt_buttons(shelf):
    """Delete every existing KeyBelt button on the shelf tab."""
    removed = 0
    for child in cmds.shelfLayout(shelf, query=True, childArray=True) or []:
        try:
            if not cmds.shelfButton(child, exists=True):
                continue
            label = cmds.shelfButton(child, query=True, label=True)
            doc_tag = cmds.shelfButton(child, query=True, docTag=True)
            if label == BUTTON_LABEL or doc_tag == BUTTON_DOCTAG:
                cmds.deleteUI(child)
                removed += 1
        except Exception:
            continue
    return removed


def create_shelf_button(root):
    """Create / refresh the KeyBelt shelf tab and button. Returns the button name."""
    top = _shelf_top_level()
    if not cmds.shelfLayout(SHELF_NAME, exists=True):
        cmds.shelfLayout(SHELF_NAME, parent=top)
    _remove_keybelt_buttons(SHELF_NAME)

    button = cmds.shelfButton(
        parent=SHELF_NAME,
        image=_icon_path(root),
        label=BUTTON_LABEL,
        annotation=BUTTON_ANNOTATION,
        docTag=BUTTON_DOCTAG,
        command=_bootstrap(root, "show()"),
        sourceType="python",
        imageOverlayLabel="",
        style="iconOnly",
        width=32,
        height=32,
    )
    try:
        cmds.tabLayout(top, edit=True, selectTab=SHELF_NAME)
    except Exception:
        pass
    return button


# ---------------------------------------------------------------------------
# userSetup.py (logic lives in keybelt_startup.py, shared with keybelt_core)
# ---------------------------------------------------------------------------
def install_user_setup(root):
    """Add or replace the KeyBelt block in userSetup.py. Returns the file path."""
    mod = _startup_module(root)
    path = _user_setup_path()
    mod.set_enabled(True, root=root, path=path)
    return path


def remove_user_setup_block(root=None):
    """Remove the KeyBelt block from userSetup.py. Returns True when something was removed."""
    mod = _startup_module(root)
    path = _user_setup_path()
    if not mod.is_enabled(path):
        return False
    mod.set_enabled(False, path=path)
    return True


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def install(root=None):
    """Create the shelf button and the userSetup.py auto-start block."""
    root = _root_dir(root)
    if not (os.path.isfile(os.path.join(root, "keybelt_core.py"))
            or (_is_release(root) and any(n.startswith("keybelt_core.") and n.endswith(".pyd") for n in os.listdir(root)))):
        cmds.confirmDialog(title="KeyBelt", message="keybelt_core.py not found next to the installer:\n" + root,
                           button=["OK"], icon="critical")
        return False

    # Maya may call both the drop callback and run __main__: install only once.
    now = time.time()
    try:
        if cmds.optionVar(exists=_STAMP_OPTIONVAR) and now - cmds.optionVar(query=_STAMP_OPTIONVAR) < 3.0:
            return True
        cmds.optionVar(floatValue=(_STAMP_OPTIONVAR, now))
    except Exception:
        pass

    status = "in place"
    if _is_release(root):
        target = _stable_install_dir()
        if _same_path(root, target):
            status = "installed"
        else:
            try:
                status = _deploy_release(root, target)
            except Exception as err:
                cmds.confirmDialog(title="KeyBelt", message="KeyBelt could not be copied to:\n{0}\n\n{1}".format(target, err),
                                   button=["OK"], icon="critical")
                return False
        root = target

    create_shelf_button(root)
    setup_path = install_user_setup(root)
    _save_shelves()

    print("=" * 60)
    print("KeyBelt installed")
    print("  Folder    : {0}".format(root))
    if status == "pending":
        print("  Update    : staged, applied when Maya restarts (KeyBelt is loaded right now)")
    print("  Shelf     : {0}".format(SHELF_NAME))
    print("  userSetup : {0}".format(setup_path))
    print("  Click the KeyBelt shelf button to start (it also starts automatically with Maya).")
    print("=" * 60)

    try:
        cmds.inViewMessage(amg="<hl>KeyBelt update staged - restart Maya</hl>" if status == "pending"
                           else "<hl>KeyBelt installed</hl>", pos="midCenter", fade=True)
    except Exception:
        pass
    try:
        if not cmds.about(batch=True):
            cmds.confirmDialog(
                title="KeyBelt",
                message=("KeyBelt update staged.\n\nRestart Maya to finish the update." if status == "pending"
                         else "KeyBelt installed.\n\nUse the 'KeyBelt' shelf tab, or restart Maya to auto-start it."),
                button=["OK"],
            )
    except Exception:
        pass
    return True


def uninstall():
    """Remove the KeyBelt shelf tab, its shelf file and the userSetup.py block."""
    removed = []
    if cmds.shelfLayout(SHELF_NAME, exists=True):
        try:
            cmds.deleteUI(SHELF_NAME, layout=True)
            removed.append("shelf tab")
        except Exception as err:
            print("KeyBelt: could not delete shelf tab ({0})".format(err))
    shelf_file = os.path.join(cmds.internalVar(userShelfDir=True), "shelf_{0}.mel".format(SHELF_NAME))
    for candidate in (shelf_file, shelf_file + ".deleted"):
        if os.path.isfile(candidate):
            try:
                os.remove(candidate)
                removed.append("shelf file")
            except Exception as err:
                print("KeyBelt: could not delete {0} ({1})".format(candidate, err))
    if remove_user_setup_block():
        removed.append("userSetup.py block")
    _save_shelves()
    try:
        cmds.optionVar(remove=_STAMP_OPTIONVAR)
    except Exception:
        pass
    print("KeyBelt uninstalled ({0}). Delete the KeyBelt folder to remove the files; "
          "settings live in <maya prefs>/keybelt/.".format(", ".join(removed) or "nothing to remove"))
    return removed


def onMayaDroppedPythonFile(*args, **kwargs):
    """Called by Maya when this file is dropped into the viewport."""
    hint = args[0] if args else None
    install(hint)


if __name__ == "__main__":
    install()
