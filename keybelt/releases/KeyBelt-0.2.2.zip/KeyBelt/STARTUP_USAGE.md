# KeyBelt - Startup Integration

KeyBelt starts automatically with Maya after you install it with `drag_n_drop.py`
(drag the file into a Maya viewport). The installer writes a managed block into your
`userSetup.py`:

```python
# >>> KeyBelt >>>
# ... registers the "keybelt" package and calls keybelt_core.show_startup() once Maya's UI is ready ...
# <<< KeyBelt <<<
```

Do not edit text between the markers. Re-dropping the installer replaces the block
(use this after moving the KeyBelt folder). `drag_n_drop.uninstall()` removes it.

You can also toggle it without the installer: Settings > General > Startup >
**Load at Maya startup** (adds / removes the same block in the versioned `userSetup.py`;
takes effect the next time Maya starts; the previous file is saved as `userSetup.py.bak`).
Scripted: `keybelt_core.is_startup_enabled()` / `keybelt_core.set_startup_enabled(True/False)`.
A hand-written `<maya prefs>/scripts/userSetup.py` that loads KeyBelt is never edited - the
settings show "Also loaded by <path> (edit manually)".

## Migrating from a pre-`keybelt` package block

Older installs wrote a block that put the KeyBelt folder on `sys.path`, purged same-named modules of
other toolsets and did `import keybelt_core`. KeyBelt is now the package `keybelt` and never uses
`sys.path`. **Re-drop `drag_n_drop.py` once** (or untick and tick Settings > General > Startup >
Load at Maya startup) to rewrite the block and the shelf button. Until then an old block still works
(a bare `import keybelt_core` is forwarded to `keybelt.keybelt_core`), but its purge step can unload
modules of another toolset - migrate it.

## Manual setup (without the installer)

Add this to your `userSetup.py` (adjust the path). The folder can have any name:

```python
import maya.utils

def _keybelt_startup():
    import importlib.util, sys
    root = r"C:\path\to\KeyBelt"
    if "keybelt" not in sys.modules:
        spec = importlib.util.spec_from_file_location(
            "keybelt", root + "/__init__.py", submodule_search_locations=[root])
        pkg = importlib.util.module_from_spec(spec)
        sys.modules["keybelt"] = pkg
        spec.loader.exec_module(pkg)
    import keybelt.keybelt_core as kb
    kb.show_startup()

maya.utils.executeDeferred(_keybelt_startup)
```

After `keybelt_core.unload_all()` the `keybelt` package is removed from `sys.modules`; use the KeyBelt
shelf button (or run the block above again) to load it again.

## Entry points

| Function | Use |
| --- | --- |
| `keybelt.keybelt_core.show()` | Standard launch (shelf button) |
| `keybelt_core.show_startup()` | Startup-safe launch: waits for Maya UI, then launches |
| `keybelt_core.show_docked()` / `show_floating()` | Aliases of `show()` (no window exists any more; kept for old shelf buttons) |
| `keybelt_core.unload_all()` | Unload KeyBelt from the session (also Settings > General > Session) |

## What `show_startup()` does

1. Waits for Maya's UI to be ready.
2. Launches headless (there is no tool-list window): builds the timeline toolbar, attaches the
   Graph Editor toolbar, starts the floating Viewport Bar (if enabled in Settings), registers the radial menu hotkey
   and schedules the settings hint.
3. Closes and deletes a stale `KeyBeltWorkspaceControl` restored by Maya from an old
   saved layout.

## Settings location

User settings are stored in `<maya prefs>/keybelt/` (outside the KeyBelt folder, so
they survive updates).

## Release builds: install location and updates

A release build (`BUILD_INFO.json` present) is installed to `<Documents>/maya/KeyBelt` by
`drag_n_drop.py`; the managed block points at that folder. Before importing KeyBelt the block (and the
shelf button) runs `keybelt_update.apply_pending(root)`, which swaps in a staged update
(`<Documents>/maya/KeyBelt_pending`) when there is one; after `show_startup()` it starts the
background automatic update (a few seconds later, at most once a day: check, download, verify, stage;
the staged version is swapped in at the next start and a one-time "Updated to x.y.z" message is shown).
Switch it off in Settings > General > Updates > "Update KeyBelt automatically". Development source folders never check or apply updates.
