"""Main container package exports.

Keeping `show` at package level makes `import main` usage robust in tools that
expect `main.show(...)`.
"""

from .main import MainContainer, close_existing_windows, show

__all__ = ["MainContainer", "close_existing_windows", "show"]
