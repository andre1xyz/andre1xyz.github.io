# KeyBelt

Animation toolset for Maya. Version 0.1.0 (initial public beta).

KeyBelt puts a set of animation tools in a timeline toolbar,
a floating viewport bar and a radial menu, with a Settings window to configure them.

## Requirements

- Autodesk Maya 2022 - 2026 (Windows, macOS, Linux). Supports both PySide2 (Maya 2022 - 2024)
  and PySide6 (Maya 2025+) through the shared `keybelt_qt.py` compatibility module.
- Qt compatibility is verified by import and widget-instantiate tests in `mayapy` 2024
  (PySide2) and 2025 (PySide6). Full runtime GUI behaviour (docking, mouse interaction,
  viewport overlays) should still be checked live in each Maya version.

## Install (release download)

Release builds (a zip with `KeyBelt/BUILD_INFO.json`, compiled `.pyd` modules for Maya 2023 - 2026 on
Windows) install with one drag and drop:

1. Unzip the download anywhere.
2. Drag `KeyBelt/drag_n_drop.py` into a Maya viewport.

The installer copies KeyBelt to `<Documents>/maya/KeyBelt` (the same folder for every Maya version),
overwrites an older install, creates the shelf tab and the startup block there, and you can delete the
unzipped folder. If KeyBelt is loaded while you update, the new version is applied the next time Maya
starts. KeyBelt checks for updates in the background (Settings > General > Updates; it only notifies
and downloads when you click). Release builds are built from the source with `KeyBelt_dev/build.py`.

## Install (source / development)


1. Download / clone this folder anywhere you like (keep the folder together).
2. Start Maya.
3. Drag `drag_n_drop.py` from the folder into a Maya viewport.

The installer:

- creates a shelf tab called **KeyBelt** with a KeyBelt button (re-dropping replaces the button),
- adds a block to your `userSetup.py` (between `# >>> KeyBelt >>>` and `# <<< KeyBelt <<<`) so
  KeyBelt starts with Maya,
  (toggle it later in Settings > General > Startup > **Load at Maya startup**),
- shows a "KeyBelt installed" confirmation.

Click the shelf button to launch KeyBelt. If you move or rename the folder, drop `drag_n_drop.py` again.

KeyBelt is loaded as the Python package `keybelt`, registered from the folder you installed it in
(its folder is **not** added to `sys.path`). This lets it run in the same Maya session as other
toolsets that use common module names such as `main` or `RadialMenu`, and each can be loaded and
unloaded independently.

**Updating from a version before the `keybelt` package:** drop `drag_n_drop.py` once more (or switch
Settings > General > Startup > Load at Maya startup off and on) so the shelf button and the
`userSetup.py` block are regenerated.

## Tools

| Tool | What it does |
| --- | --- |
| Baker | Bake animation in world space or in an object space |
| Keys Editor | Slider based key effects (interpolate, push/pull, ease, wave, offset ...) and key cleanup |
| Offseter | Offsets the animation based on the transform you give the selected object |
| Reset All | Reset all keyable channels of the selection to their defaults |
| Selector | Always-on HUD for selection sets |
| Graph Editor toolbar | Keys Editor sliders and action buttons attached to the Graph Editor (Settings > Graph Editor) |
| Motion Trail **(BETA)** | Viewport motion trails (world or camera relative). Features may change |

Tools marked BETA carry a `BETA` marker file in their folder; KeyBelt shows a BETA badge for them.

## Settings

Open the gear button on the timeline toolbar (KeyBelt Settings): toolbar placement and order,
hotkeys, radial menu and viewport bar contents, and the documentation.

Settings files are stored in `<maya prefs>/keybelt/` (for example
`Documents/maya/<version>/prefs/keybelt/` on Windows), so they survive updates.

Documentation: open `Documentation/index.html` or use Settings > Documentation.

## Uninstall

In the Maya Script Editor (Python tab):

```python
import importlib.util
spec = importlib.util.spec_from_file_location("keybelt_installer", r"C:\path\to\KeyBelt\drag_n_drop.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
mod.uninstall()
```

This removes the **KeyBelt** shelf tab and the `userSetup.py` block. Delete the KeyBelt folder to
remove the files, and `<maya prefs>/keybelt/` to remove saved settings.

## Brand colours

| Name | Hex |
| --- | --- |
| KEYBLACK | `#0D0D0D` |
| IVORY | `#F7F7F5` |

Brand assets live in `branding/`.

## License

Free to use (personal and commercial), no redistribution or modification. See `EULA.txt` (draft,
pending review) and `LICENSE.txt`.
