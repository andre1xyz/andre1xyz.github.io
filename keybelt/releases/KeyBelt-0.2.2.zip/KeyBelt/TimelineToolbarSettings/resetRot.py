"""Reset rotation of the selected nodes (rx/ry/rz = 0). One undo step.

Plain maya.cmds (no PyMEL): PyMEL 1.5 has no Maya 2026 API cache and fails to load.
Locked / connected / missing channels are skipped silently.
"""
import maya.cmds as cmds

ATTRS = ('rx', 'ry', 'rz')
VALUE = 0


def reset_selected(nodes=None):
    nodes = nodes if nodes is not None else (cmds.ls(selection=True, long=True) or [])
    cmds.undoInfo(openChunk=True, chunkName="resetRot")
    try:
        for node in nodes:
            for attr in ATTRS:
                plug = "{}.{}".format(node, attr)
                try:
                    if cmds.getAttr(plug, settable=True):
                        cmds.setAttr(plug, VALUE)
                except Exception:
                    pass
    finally:
        cmds.undoInfo(closeChunk=True)


reset_selected()
