# -*- coding: utf-8 -*-
"""
KeyBelt updater (plain Python, standard library only, no Maya import at module level)
=====================================================================================

* check()               fetch version.json (5 s timeout, at most once per 24 h unless forced)
* download_and_stage()  download the release zip, verify sha256 + size, validate it and
                        stage it as <install parent>/KeyBelt_pending/
* apply_pending(root)   called by the bootstrap BEFORE any keybelt module is imported:
                        swaps KeyBelt_pending in (rolls back on error)

Nothing is ever downloaded without an explicit user action. Development source
(no BUILD_INFO.json next to this file) never checks, stages or applies anything.
Only HTTPS and only the release site below are used (tests may pass another base
URL with allow_insecure=True).
"""

import hashlib
import json
import os
import shutil
import sys
import tempfile
import threading
import time
import zipfile

try:
    from urllib.request import Request, urlopen
except ImportError:  # pragma: no cover
    from urllib2 import Request, urlopen

BASE_URL = "https://andre1xyz.github.io/keybelt/"
CHECK_INTERVAL = 24 * 3600
TIMEOUT = 5
DOWNLOAD_TIMEOUT = 60
MAX_ZIP_BYTES = 400 * 1024 * 1024
PENDING_NAME = "KeyBelt_pending"
OLD_NAME = "KeyBelt_old"
DEV_STATUS = "dev build"


# ---------------------------------------------------------------------------
# Paths / state
# ---------------------------------------------------------------------------
def root_dir():
    return os.path.dirname(os.path.abspath(__file__))


def build_info(root=None):
    """BUILD_INFO.json as dict, or None for a development source folder."""
    try:
        with open(os.path.join(root or root_dir(), "BUILD_INFO.json"), "r") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def is_release(root=None):
    return build_info(root) is not None


def current_version(root=None):
    info = build_info(root)
    if info and info.get("version"):
        return str(info["version"])
    try:
        with open(os.path.join(root or root_dir(), "VERSION"), "r") as fh:
            return fh.read().strip() or "0.0.0"
    except Exception:
        return "0.0.0"


def channel(root=None):
    return "Release" if is_release(root) else "Dev source"


def abi_tag():
    return "cp{0}{1}".format(sys.version_info[0], sys.version_info[1])


def prefs_dir():
    """<maya prefs>/keybelt (created). Falls back to a temp dir outside Maya."""
    base = None
    try:
        import maya.cmds as cmds
        base = cmds.internalVar(userPrefDir=True)
    except Exception:
        base = os.path.join(tempfile.gettempdir(), "keybelt_prefs")
    path = os.path.join(base, "keybelt")
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


def _state_path(state_dir=None):
    return os.path.join(state_dir or prefs_dir(), "update_state.json")


def load_state(state_dir=None):
    try:
        with open(_state_path(state_dir), "r") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_state(state, state_dir=None):
    try:
        path = _state_path(state_dir)
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(state, fh, indent=2)
        os.replace(tmp, path)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Versions
# ---------------------------------------------------------------------------
def parse_version(text):
    """'1.2.3' / 'v1.2' / '1.2.3-beta' -> (1, 2, 3, 1|0). Pre-releases sort below the release."""
    text = str(text or "").strip().lstrip("vV")
    pre = 0
    for sep in ("-", "+"):
        if sep in text:
            text = text.split(sep, 1)[0]
            pre = 1 if sep == "-" else 0
    nums = []
    for part in text.split("."):
        digits = "".join(ch for ch in part if ch.isdigit())
        nums.append(int(digits) if digits else 0)
    while len(nums) < 3:
        nums.append(0)
    return tuple(nums[:3]) + (0 if pre else 1,)


def is_newer(latest, current):
    return parse_version(latest) > parse_version(current)


# ---------------------------------------------------------------------------
# Network helpers
# ---------------------------------------------------------------------------
def _check_url(url, base_url, allow_insecure):
    base = base_url or BASE_URL
    if not url.startswith(base):
        raise ValueError("URL outside the release site: {0}".format(url))
    if not (url.startswith("https://") or (allow_insecure and url.startswith("http://"))):
        raise ValueError("HTTPS required: {0}".format(url))


def _http_get(url, timeout):
    req = Request(url, headers={"User-Agent": "KeyBelt-updater"})
    resp = urlopen(req, timeout=timeout)
    try:
        return resp.read()
    finally:
        resp.close()


def _fetch_version_json(base_url, allow_insecure):
    url = (base_url or BASE_URL).rstrip("/") + "/version.json"
    _check_url(url, base_url, allow_insecure)
    data = json.loads(_http_get(url, TIMEOUT).decode("utf-8"))
    if not isinstance(data, dict) or not data.get("version") or not data.get("url"):
        raise ValueError("malformed version.json")
    return data


# ---------------------------------------------------------------------------
# check
# ---------------------------------------------------------------------------
def check(force=False, base_url=None, allow_insecure=False, root=None, state_dir=None, now=None):
    """Return a dict: {"status", "current", "latest", "info", "message"}.

    status: "dev build" | "up to date" | "update available" | "error".
    ``cached`` is True when the answer came from the 24 h cache (no network).
    """
    root = root or root_dir()
    cur = current_version(root)
    result = {"status": DEV_STATUS, "current": cur, "latest": None, "info": None,
              "message": "Development build - updates disabled", "cached": False}
    if not is_release(root):
        return result
    now = time.time() if now is None else now
    try:
        state = load_state(state_dir)
        info = state.get("info") if isinstance(state.get("info"), dict) else None
        fresh = (now - float(state.get("last_check", 0))) < CHECK_INTERVAL and info
        if fresh and not force:
            result["cached"] = True
        else:
            info = _fetch_version_json(base_url, allow_insecure)
            state["last_check"] = now
            state["info"] = info
            save_state(state, state_dir)
        result["info"] = info
        result["latest"] = str(info["version"])
        if is_newer(result["latest"], cur):
            result["status"] = "update available"
            result["message"] = "KeyBelt {0} is available (you have {1})".format(result["latest"], cur)
        else:
            result["status"] = "up to date"
            result["message"] = "You have the latest version ({0})".format(cur)
    except Exception as err:
        result["status"] = "error"
        result["message"] = "Update check failed: {0}".format(err)
    return result


# ---------------------------------------------------------------------------
# download + stage
# ---------------------------------------------------------------------------
def pending_dir(root=None):
    return os.path.join(os.path.dirname(os.path.abspath(root or root_dir())), PENDING_NAME)


def _rmtree(path):
    if os.path.isdir(path):
        shutil.rmtree(path, ignore_errors=True)
    return not os.path.exists(path)


def _safe_extract(zf, dest):
    dest_abs = os.path.abspath(dest)
    for member in zf.namelist():
        target = os.path.abspath(os.path.join(dest_abs, member))
        if target != dest_abs and not target.startswith(dest_abs + os.sep):
            raise ValueError("unsafe path in zip: {0}".format(member))
    zf.extractall(dest_abs)


def _validate_package(folder, abi):
    if not os.path.isfile(os.path.join(folder, "BUILD_INFO.json")):
        raise ValueError("zip has no KeyBelt/BUILD_INFO.json")
    if not os.path.isfile(os.path.join(folder, "drag_n_drop.py")):
        raise ValueError("zip has no drag_n_drop.py")
    suffix = "." + abi + "-"
    found = False
    for _dirpath, _dirs, files in os.walk(folder):
        if any(f.endswith(".pyd") and suffix in f for f in files):
            found = True
            break
    if not found:
        raise ValueError("zip has no compiled modules for this Maya's Python ({0})".format(abi))


def download_and_stage(info=None, base_url=None, allow_insecure=False, root=None, abi=None, state_dir=None):
    """Download + verify + stage the release described by ``info`` (version.json dict).

    Returns {"ok": bool, "version": str, "message": str}. Never raises.
    """
    root = root or root_dir()
    if not is_release(root):
        return {"ok": False, "version": None, "message": "Development build - updates disabled"}
    tmp_dir = None
    try:
        if info is None:
            info = _fetch_version_json(base_url, allow_insecure)
        url = str(info["url"])
        sha = str(info["sha256"]).lower()
        size = int(info["size"])
        version = str(info["version"])
        _check_url(url, base_url, allow_insecure)
        if size <= 0 or size > MAX_ZIP_BYTES:
            raise ValueError("bad size in version.json")
        tmp_dir = tempfile.mkdtemp(prefix="keybelt_update_")
        zip_path = os.path.join(tmp_dir, "KeyBelt.zip")
        digest = hashlib.sha256()
        total = 0
        req = Request(url, headers={"User-Agent": "KeyBelt-updater"})
        resp = urlopen(req, timeout=DOWNLOAD_TIMEOUT)
        try:
            with open(zip_path, "wb") as out:
                while True:
                    chunk = resp.read(1 << 16)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > size:
                        raise ValueError("download larger than announced")
                    digest.update(chunk)
                    out.write(chunk)
        finally:
            resp.close()
        if total != size:
            raise ValueError("size mismatch ({0} != {1})".format(total, size))
        if digest.hexdigest().lower() != sha:
            raise ValueError("sha256 mismatch")

        parent = os.path.dirname(os.path.abspath(root))
        staging = os.path.join(parent, "KeyBelt_staging")
        _rmtree(staging)
        os.makedirs(staging)
        try:
            with zipfile.ZipFile(zip_path) as zf:
                _safe_extract(zf, staging)
            new_root = os.path.join(staging, "KeyBelt")
            _validate_package(new_root, abi or abi_tag())
            pending = pending_dir(root)
            _rmtree(pending)
            os.rename(new_root, pending)
        finally:
            _rmtree(staging)
        state = load_state(state_dir)
        state["pending_version"] = version
        save_state(state, state_dir)
        return {"ok": True, "version": version,
                "message": "Update {0} ready - restart Maya to finish".format(version)}
    except Exception as err:
        return {"ok": False, "version": None, "message": "Update failed: {0}".format(err)}
    finally:
        if tmp_dir:
            _rmtree(tmp_dir)


def pending_version(root=None):
    """Version of the staged update, or None."""
    info = build_info(pending_dir(root))
    return str(info.get("version")) if info and info.get("version") else None


def stage_folder(src, root=None):
    """Stage an already extracted KeyBelt folder as KeyBelt_pending (used by the installer)."""
    pending = pending_dir(root)
    _rmtree(pending)
    shutil.copytree(src, pending, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    return pending


# ---------------------------------------------------------------------------
# apply
# ---------------------------------------------------------------------------
def apply_pending(root=None):
    """Swap <parent>/KeyBelt_pending in. Returns True when the swap happened.

    Must run before any keybelt module (.pyd) of ``root`` is imported. A locked folder
    (KeyBelt loaded in another Maya) leaves the pending update in place for next time.
    Dev source: never touches anything.
    """
    root = os.path.abspath(root or root_dir())
    try:
        if not is_release(root) and os.path.isdir(root):
            return False
        parent = os.path.dirname(root)
        pending = os.path.join(parent, PENDING_NAME)
        old = os.path.join(parent, OLD_NAME)
        # Crash recovery: a swap that died between the two renames.
        if not os.path.isdir(root) and os.path.isdir(old):
            os.rename(old, root)
        if not os.path.isdir(pending):
            return False
        if not (os.path.isfile(os.path.join(pending, "BUILD_INFO.json")) and _has_core(pending)):
            _rmtree(pending)
            return False
        _rmtree(old)
        if os.path.exists(old):
            return False
        try:
            os.rename(root, old)
        except OSError as err:
            print("KeyBelt: update postponed ({0})".format(err))
            return False
        try:
            os.rename(pending, root)
        except Exception as err:
            try:
                if not os.path.isdir(root):
                    os.rename(old, root)
            except Exception:
                pass
            print("KeyBelt: update failed, rolled back ({0})".format(err))
            return False
        _rmtree(old)
        print("KeyBelt: updated to {0}".format(current_version(root)))
        try:
            with open(os.path.join(root, UPDATED_MARKER), "w") as fh:
                fh.write(current_version(root) or "")
        except Exception:
            pass
        return True
    except Exception as err:
        print("KeyBelt: update not applied ({0})".format(err))
        return False


UPDATED_MARKER = ".keybelt_just_updated"


def pop_just_updated(root=None):
    """Version KeyBelt was just updated to (read once, then forgotten), or None."""
    path = os.path.join(root or root_dir(), UPDATED_MARKER)
    try:
        with open(path, "r") as fh:
            version = fh.read().strip()
        os.remove(path)
        return version or None
    except Exception:
        return None


def auto_update(base_url=None, allow_insecure=False, root=None, abi=None, state_dir=None, now=None):
    """Check and, when a newer version exists, download + verify + stage it. Never raises.

    Returns {"status": "staged" | "pending" | "up to date" | "error" | "dev build", "version", "message"}.
    The staged update is swapped in by apply_pending() the next time Maya starts.
    """
    root = root or root_dir()
    res = check(base_url=base_url, allow_insecure=allow_insecure, root=root, state_dir=state_dir, now=now)
    status = res.get("status")
    if status != "update available":
        return {"status": status, "version": res.get("latest"), "message": res.get("message")}
    latest = res.get("latest")
    if pending_version(root) == latest:
        return {"status": "pending", "version": latest,
                "message": "KeyBelt {0} installs the next time Maya starts".format(latest)}
    staged = download_and_stage(info=res.get("info"), base_url=base_url, allow_insecure=allow_insecure,
                                root=root, abi=abi, state_dir=state_dir)
    if staged.get("ok"):
        return {"status": "staged", "version": latest,
                "message": "KeyBelt {0} is ready. It installs the next time you start Maya".format(latest)}
    return {"status": "error", "version": latest, "message": staged.get("message")}


def _has_core(folder):
    for name in os.listdir(folder):
        if name == "keybelt_core.py" or (name.startswith("keybelt_core.") and name.endswith(".pyd")):
            return True
    return False


# ---------------------------------------------------------------------------
# Background helpers (Maya side; never block the main thread)
# ---------------------------------------------------------------------------
def auto_check_enabled(state_dir=None):
    """"Update KeyBelt automatically" (Settings > General > Updates, default on).

    Stored by keybelt_core in the timeline settings JSON ("update_auto_check").
    """
    try:
        path = os.path.join(state_dir or prefs_dir(), "timeline_toolbar_settings.json")
        with open(path, "r") as fh:
            data = json.load(fh)
        return bool(data.get("update_auto_check", True)) if isinstance(data, dict) else True
    except Exception:
        return True


def run_async(func, callback=None, *args, **kwargs):
    """Run func(*args, **kwargs) in a daemon thread; callback(result) runs on Maya's main thread."""
    def _work():
        try:
            result = func(*args, **kwargs)
        except Exception as err:
            result = {"status": "error", "ok": False, "message": str(err)}
        if callback is None:
            return
        try:
            import maya.utils
            maya.utils.executeDeferred(callback, result)
        except Exception:
            try:
                callback(result)
            except Exception:
                pass
    thread = threading.Thread(target=_work, name="keybelt-update")
    thread.daemon = True
    thread.start()
    return thread


def _notify(msg):
    if not msg:
        return
    print("KeyBelt: " + msg)
    try:
        import maya.cmds as cmds
        if not cmds.about(batch=True):
            cmds.inViewMessage(amg="<hl>KeyBelt</hl>: " + msg, pos="botRight", fade=True,
                               fadeStayTime=6000)
    except Exception:
        pass


def startup_check(delay=8.0):
    """Release builds only, a few seconds after startup, in the background.

    Says "updated to X" once after an update was installed. With automatic updates on
    (default) it also checks (at most once a day), downloads and verifies a newer
    version and stages it; it installs by itself the next time Maya starts.
    """
    if not is_release():
        return None
    just_updated = pop_just_updated()
    try:
        auto = auto_check_enabled()
    except Exception:
        auto = False

    def _job():
        if delay:
            time.sleep(delay)
        if not auto:
            return {"status": "off"}
        result = auto_update()
        if result.get("status") == "error":
            print("KeyBelt: update not downloaded ({0})".format(result.get("message")))
        return result

    def _done(result):
        if just_updated:
            _notify("Updated to {0}".format(just_updated))
        if isinstance(result, dict) and result.get("status") == "staged":
            _notify(result.get("message"))
    return run_async(_job, _done)
