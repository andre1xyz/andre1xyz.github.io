# Release build: the package re-exports the compiled MotionTrail module.
from . import MotionTrail as _mt_module

__all__ = []
for _name in ("launch", "show", "run_motion_trail", "MotionTrailWindow", "MotionTrailAgora"):
    if hasattr(_mt_module, _name):
        globals()[_name] = getattr(_mt_module, _name)
        __all__.append(_name)
