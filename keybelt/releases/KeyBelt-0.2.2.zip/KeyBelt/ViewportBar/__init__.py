# -*- coding: utf-8 -*-
"""Viewport Bar package (floating toolbar inside every Maya model panel)."""
